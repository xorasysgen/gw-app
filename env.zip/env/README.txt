Prerequisites :

aims.properties to be configured accordingly
#############################
##      GW-APP  Setup       #
#############################

json.body.key.username=admin 			#username of installed aims
json.body.period=5				#free to update value
json.body.count=12				#free to update value
json.body.filename=data_ClientPollPram 		#do not change unless gateway having any update
json.body.extension=.json  			#do not change unless gateway having any update
gw.target.protocol=https			#do not change unless gateway having any update
gw.target.port=443				#do not change unless gateway having any update
gw.target.uri=api/v2/gw/poll 			#do not change unless gateway having any update

cs.target.protocol=https
cs.target.ip=52.141.19.179			#change aims server IP
cs.target.port:3000				#do not change unless protal having any update
cs.target.uri=aims_plus/gw/all?stationCode=all  #do not change unless protal having any update
cs.target.final=${cs.target.protocol}://${cs.target.ip}:${cs.target.port}/${cs.target.uri}		#do not change

#execution threshold : no of times to be looped[once it finised task, it will start again to max execution.limit value]
execution.limit=1				#do not change unless you want repeated operation 




Step 1 : extract folder env into C: Drive
Step 2 : change directory to env i,e- c:/cd env
Step 3 : java -jar -Daims.root.path=C:\ api-v2-gw.jar

OPEN browse type url below:Execution  : Type  [http://localhost:8080/execute]
Logging    : Check log inside /env/log/api-v2-gw.log